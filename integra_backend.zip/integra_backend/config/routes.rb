Rails.application.routes.draw do
  resources :carrots
  
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html
  resources :logamorph do
    resources :carrots
  end

  resources :barn do
    resources :carrots
  end
  # Defines the root path route ("/")
  # root "articles#index"
end
