require "test_helper"

class CarrotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
