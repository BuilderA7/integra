require "test_helper"

class BarnTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
