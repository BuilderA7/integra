class CreateLogamorphs < ActiveRecord::Migration[7.0]
  def change
    create_table :logamorphs do |t|

      t.timestamps
    end
  end
end
