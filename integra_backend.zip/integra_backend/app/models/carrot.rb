class Carrot < ApplicationRecord
end
