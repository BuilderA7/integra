class Barn < ApplicationRecord
    has_many :carrots
end
