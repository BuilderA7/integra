class Logamorph < ApplicationRecord
    has_many :carrots
end
