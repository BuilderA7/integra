class BarnController < ApplicationController
    def index
        @Barn = Carrot.all
        render json: @Barn
      end
      def show
        render json: @Barn
      end
end
