class LogamorphController < ApplicationController
    def index
        @carrots = Carrot.all
        render json: @carrots
    end
    def show
        render json: @carrots
    end
end
